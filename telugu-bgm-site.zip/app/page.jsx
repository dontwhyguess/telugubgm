
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Instagram } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-white text-black px-4 py-10 md:px-10 font-sans">
      <div className="max-w-4xl mx-auto text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-4">TELUGU BGM</h1>
        <p className="text-lg md:text-xl text-gray-600 mb-8">
          Professional Video Edits, EFX, and Slow-Motion Magic for Instagram Creators.
        </p>

        <a
          href="https://instagram.com/telugu.bgm"
          target="_blank"
          rel="noopener noreferrer"
        >
          <Button className="bg-black text-white text-lg px-6 py-4 rounded-2xl hover:bg-gray-900">
            <Instagram className="w-5 h-5 mr-2" /> DM Us on Instagram
          </Button>
        </a>

        <div className="mt-16 grid md:grid-cols-3 gap-6">
          {[
            {
              title: "Video Editing",
              desc: "Cinematic and trendy edits tailored for Instagram Reels.",
            },
            {
              title: "Special Effects (EFX)",
              desc: "Add eye-catching effects that bring your clips to life.",
            },
            {
              title: "Slow Motion Edits",
              desc: "Smooth slow-mo to highlight the best moments in your videos.",
            },
          ].map((service) => (
            <Card key={service.title} className="rounded-2xl shadow-md">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                <p className="text-gray-600">{service.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <footer className="mt-20 text-gray-400 text-sm">
          © 2025 TELUGU BGM. All rights reserved.
        </footer>
      </div>
    </div>
  );
}
